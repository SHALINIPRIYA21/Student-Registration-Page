package com.Db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class prog2 {

	public static void main(String[] args) {
		
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "shalini");
			
			/*
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter ID:  ");
			int id= sc.nextInt();
			
			System.out.println("Enter Name: ");
			String name= sc.next();
			
			System.out.println("Enter Address : ");
			String address= sc.next();
			
			
			PreparedStatement ps =  conn.prepareStatement("insert into studentinfo values(?,?,?)");
			ps.setInt(1,id);
			ps.setString(2, name);
			ps.setString(3, address);
			
			
			int a =  ps.executeUpdate();
			System.out.println("insert and update  successfully! yaaahoooo");
			*/
			
			
		/*	Scanner sc= new Scanner(System.in);
			System.out.println("Enter ID:  ");
			int id= sc.nextInt();
			
			
			System.out.println("Enter Address : ");
			String address= sc.next();

          PreparedStatement ps =  conn.prepareStatement("update studentinfo set address=? where id=?");
			
			ps.setString(1, address);
			ps.setInt(2, id);

            int a =  ps.executeUpdate();
			System.out.println(" update  successfully! yaaahoooo");
			
			*/
			
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter ID:  ");
			int id= sc.nextInt();
			
			
			
          PreparedStatement ps =  conn.prepareStatement("delete from studentinfo where id=?");
			
			
			ps.setInt(1, id);

            int a =  ps.executeUpdate();
			System.out.println(" delete  successfully! yaaahoooo");
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
		
	}
}
