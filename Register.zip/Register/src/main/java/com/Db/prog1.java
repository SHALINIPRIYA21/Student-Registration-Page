package com.Db;
import java.sql.*;


public class prog1 {
	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "shalini");
			
			// insert data into database
			//PreparedStatement ps =  conn.prepareStatement("insert into studentinfo values(?,?,?)");
			
			//ps.setInt(1,123);
			//ps.setString(2, "shalini");
			//ps.setString(3, "Banka");
			
			
			// update data into database
			/* PreparedStatement ps =  conn.prepareStatement("update studentinfo set name=?, address=? where id=?");
			
			
			ps.setString(1, "shalini priya");
			ps.setString(2, "Banka Bihar");
			ps.setInt(3, 122);
			
			
			int i =  ps.executeUpdate();
			System.out.println("insert and update  successfully! yaaahoooo");
			
			*/
			
			// delete data into database..
     /*PreparedStatement ps =  conn.prepareStatement("delete from studentinfo where id=?");
			
			
			
			ps.setInt(1, 124);
			
			int i =  ps.executeUpdate();
			System.out.println("delete   successfully! yaaahoooo");
			
			*/
			
			//fetch data 
         PreparedStatement ps =  conn.prepareStatement("select * from studentinfo");
			
			ResultSet rs  =  ps.executeQuery();
			
			 //boolean f = rs.next();
			
			//System.out.println(f);
			
			while(rs.next()) {
				System.out.println("id= " + rs.getInt(1) + " name= " + rs.getString(2) + " address= " + rs.getString(3) );
				
			}
			
			conn.close();
			
			
	}catch(Exception e) {
		e.printStackTrace();
	}
	}

}
